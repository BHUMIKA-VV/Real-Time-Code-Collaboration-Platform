import React, { useState, useEffect } from 'react';
import LoginPage from './components/Auth/LoginPage';
import CodeEditor from './components/CodeEditor/CodeEditor';
import Sidebar from './components/Sidebar/Sidebar';
import Header from './components/Header/Header';
import UserPresence from './components/UserPresence/UserPresence';
import { FileProvider } from './context/FileContext';
import { ThemeProvider } from './context/ThemeContext';
import { CollaborationProvider } from './context/CollaborationContext';
import { AuthProvider, useAuth } from './context/AuthContext';

const AppContent: React.FC = () => {
  const { isAuthenticated, login } = useAuth();

  if (!isAuthenticated) {
    return <LoginPage onLogin={login} />;
  }

  return (
    <FileProvider>
      <CollaborationProvider>
        <div className="h-screen bg-gray-900 text-white flex flex-col overflow-hidden">
          <Header />
          <div className="flex flex-1 overflow-hidden">
            <Sidebar />
            <div className="flex-1 flex flex-col overflow-hidden">
              <UserPresence />
              <CodeEditor />
            </div>
          </div>
        </div>
      </CollaborationProvider>
    </FileProvider>
  );
};

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;