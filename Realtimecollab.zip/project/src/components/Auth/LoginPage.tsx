import React, { useState } from 'react';
import { Code2, Users, Plus, LogIn, User, Lock, Hash } from 'lucide-react';

interface LoginPageProps {
  onLogin: (userData: { username: string; roomId: string; isNewRoom: boolean }) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [activeTab, setActiveTab] = useState<'join' | 'create'>('join');
  const [formData, setFormData] = useState({
    username: '',
    roomId: '',
    roomName: '',
    password: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.username.trim()) {
      newErrors.username = 'Username is required';
    } else if (formData.username.length < 2) {
      newErrors.username = 'Username must be at least 2 characters';
    }

    if (activeTab === 'join') {
      if (!formData.roomId.trim()) {
        newErrors.roomId = 'Room ID is required';
      }
    } else {
      if (!formData.roomName.trim()) {
        newErrors.roomName = 'Room name is required';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      const roomId = activeTab === 'create' 
        ? `room_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
        : formData.roomId;

      onLogin({
        username: formData.username,
        roomId,
        isNewRoom: activeTab === 'create'
      });
    }
  };

  const generateRoomId = () => {
    const id = `room_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    setFormData(prev => ({ ...prev, roomId: id }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="p-3 bg-blue-600 rounded-xl">
              <Code2 className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-white">CodeCollab</h1>
          </div>
          <p className="text-gray-300">Real-time collaborative code editor</p>
        </div>

        {/* Main Card */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 shadow-2xl overflow-hidden">
          {/* Tab Navigation */}
          <div className="flex">
            <button
              onClick={() => setActiveTab('join')}
              className={`flex-1 flex items-center justify-center space-x-2 py-4 px-6 transition-all ${
                activeTab === 'join'
                  ? 'bg-blue-600 text-white'
                  : 'bg-transparent text-gray-300 hover:bg-white/5'
              }`}
            >
              <LogIn className="w-4 h-4" />
              <span>Join Room</span>
            </button>
            <button
              onClick={() => setActiveTab('create')}
              className={`flex-1 flex items-center justify-center space-x-2 py-4 px-6 transition-all ${
                activeTab === 'create'
                  ? 'bg-blue-600 text-white'
                  : 'bg-transparent text-gray-300 hover:bg-white/5'
              }`}
            >
              <Plus className="w-4 h-4" />
              <span>Create Room</span>
            </button>
          </div>

          {/* Form Content */}
          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            {/* Username Field */}
            <div>
              <label className="block text-sm font-medium text-gray-200 mb-2">
                <User className="w-4 h-4 inline mr-2" />
                Username
              </label>
              <input
                type="text"
                value={formData.username}
                onChange={(e) => handleInputChange('username', e.target.value)}
                className={`w-full px-4 py-3 bg-white/10 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 transition-all ${
                  errors.username
                    ? 'border-red-500 focus:ring-red-500'
                    : 'border-white/20 focus:ring-blue-500 focus:border-blue-500'
                }`}
                placeholder="Enter your username"
              />
              {errors.username && (
                <p className="mt-1 text-sm text-red-400">{errors.username}</p>
              )}
            </div>

            {/* Conditional Fields */}
            {activeTab === 'join' ? (
              <div>
                <label className="block text-sm font-medium text-gray-200 mb-2">
                  <Hash className="w-4 h-4 inline mr-2" />
                  Room ID
                </label>
                <input
                  type="text"
                  value={formData.roomId}
                  onChange={(e) => handleInputChange('roomId', e.target.value)}
                  className={`w-full px-4 py-3 bg-white/10 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 transition-all ${
                    errors.roomId
                      ? 'border-red-500 focus:ring-red-500'
                      : 'border-white/20 focus:ring-blue-500 focus:border-blue-500'
                  }`}
                  placeholder="Enter room ID to join"
                />
                {errors.roomId && (
                  <p className="mt-1 text-sm text-red-400">{errors.roomId}</p>
                )}
              </div>
            ) : (
              <div>
                <label className="block text-sm font-medium text-gray-200 mb-2">
                  <Users className="w-4 h-4 inline mr-2" />
                  Room Name
                </label>
                <input
                  type="text"
                  value={formData.roomName}
                  onChange={(e) => handleInputChange('roomName', e.target.value)}
                  className={`w-full px-4 py-3 bg-white/10 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 transition-all ${
                    errors.roomName
                      ? 'border-red-500 focus:ring-red-500'
                      : 'border-white/20 focus:ring-blue-500 focus:border-blue-500'
                  }`}
                  placeholder="Enter room name"
                />
                {errors.roomName && (
                  <p className="mt-1 text-sm text-red-400">{errors.roomName}</p>
                )}
              </div>
            )}

            {/* Optional Password Field */}
            <div>
              <label className="block text-sm font-medium text-gray-200 mb-2">
                <Lock className="w-4 h-4 inline mr-2" />
                Password (Optional)
              </label>
              <input
                type="password"
                value={formData.password}
                onChange={(e) => handleInputChange('password', e.target.value)}
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                placeholder="Enter password (optional)"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-[1.02] focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-transparent"
            >
              {activeTab === 'join' ? 'Join Room' : 'Create Room'}
            </button>

            {/* Helper Text */}
            <div className="text-center">
              {activeTab === 'create' && (
                <p className="text-sm text-gray-400">
                  A unique room ID will be generated for sharing
                </p>
              )}
              {activeTab === 'join' && (
                <p className="text-sm text-gray-400">
                  Ask the room creator for the room ID
                </p>
              )}
            </div>
          </form>
        </div>

        {/* Footer */}
        <div className="text-center mt-6 text-gray-400 text-sm">
          <p>Start coding together in real-time</p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;