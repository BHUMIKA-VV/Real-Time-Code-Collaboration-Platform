import React, { useState, useRef } from 'react';
import Editor from '@monaco-editor/react';
import { useFile } from '../../context/FileContext';
import { useTheme } from '../../context/ThemeContext';
import LanguageSelector from './LanguageSelector';
import EditorTabs from './EditorTabs';

const CodeEditor: React.FC = () => {
  const { activeFile } = useFile();
  const { theme } = useTheme();
  const [code, setCode] = useState('// Welcome to CodeCollab!\n// Start typing to see the magic happen...\n\nfunction welcomeMessage() {\n  console.log("Happy coding! 🚀");\n  return "Ready to collaborate!";\n}\n\nwelcomeMessage();');
  const [language, setLanguage] = useState('javascript');
  const editorRef = useRef<any>(null);

  const handleEditorDidMount = (editor: any) => {
    editorRef.current = editor;
    
    // Add collaborative cursors simulation
    const decorations = editor.createDecorationsCollection([
      {
        range: new monaco.Range(2, 1, 2, 1),
        options: {
          className: 'cursor-user-2',
          stickiness: 1
        }
      }
    ]);
  };

  const getLanguageFromExtension = (extension?: string): string => {
    switch (extension) {
      case 'js':
      case 'jsx':
        return 'javascript';
      case 'ts':
      case 'tsx':
        return 'typescript';
      case 'py':
        return 'python';
      case 'java':
        return 'java';
      case 'cpp':
      case 'c':
        return 'cpp';
      case 'css':
        return 'css';
      case 'html':
        return 'html';
      case 'json':
        return 'json';
      case 'md':
        return 'markdown';
      default:
        return 'javascript';
    }
  };

  const currentLanguage = activeFile ? getLanguageFromExtension(activeFile.extension) : language;

  return (
    <div className="flex-1 flex flex-col bg-gray-900">
      <div className="flex items-center justify-between border-b border-gray-700 bg-gray-800">
        <EditorTabs />
        <div className="flex items-center space-x-4 p-2">
          <LanguageSelector 
            language={currentLanguage} 
            onLanguageChange={setLanguage} 
          />
          <div className="text-xs text-gray-400">
            Line 1, Column 1
          </div>
        </div>
      </div>
      
      <div className="flex-1 relative">
        <Editor
          height="100%"
          language={currentLanguage}
          value={code}
          theme={theme === 'dark' ? 'vs-dark' : 'light'}
          onChange={(value) => setCode(value || '')}
          onMount={handleEditorDidMount}
          options={{
            fontSize: 14,
            fontFamily: 'JetBrains Mono, Fira Code, monospace',
            minimap: { enabled: true },
            lineNumbers: 'on',
            roundedSelection: false,
            scrollBeyondLastLine: false,
            automaticLayout: true,
            tabSize: 2,
            insertSpaces: true,
            wordWrap: 'on',
            renderLineHighlight: 'line',
            selectionHighlight: false,
            cursorBlinking: 'smooth',
            cursorSmoothCaretAnimation: 'on',
            smoothScrolling: true,
            contextmenu: true,
            mouseWheelZoom: true,
            multiCursorModifier: 'ctrlCmd',
          }}
        />
        
        {/* Collaborative cursors overlay */}
        <div className="absolute top-0 left-0 pointer-events-none">
          <div className="absolute top-8 left-16 w-0.5 h-5 bg-green-400 animate-pulse">
            <div className="absolute -top-5 -left-2 bg-green-400 text-xs px-2 py-1 rounded text-black">
              Sarah
            </div>
          </div>
          <div className="absolute top-20 left-32 w-0.5 h-5 bg-purple-400 animate-pulse">
            <div className="absolute -top-5 -left-2 bg-purple-400 text-xs px-2 py-1 rounded text-black">
              Mike
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CodeEditor;