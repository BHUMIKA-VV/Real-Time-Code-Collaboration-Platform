import React from 'react';
import { X } from 'lucide-react';
import { useFile } from '../../context/FileContext';

const EditorTabs: React.FC = () => {
  const { activeFile, openFiles, closeFile, setActiveFile } = useFile();

  if (!openFiles.length) {
    return (
      <div className="flex items-center h-10 px-4 text-sm text-gray-400">
        No files open
      </div>
    );
  }

  return (
    <div className="flex items-center h-10">
      {openFiles.map((file) => (
        <div
          key={file.id}
          className={`flex items-center space-x-2 px-4 py-2 border-r border-gray-700 cursor-pointer transition-colors ${
            activeFile?.id === file.id 
              ? 'bg-gray-700 text-white' 
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
          }`}
          onClick={() => setActiveFile(file)}
        >
          <span className="text-sm">{file.name}</span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              closeFile(file.id);
            }}
            className="p-0.5 hover:bg-gray-600 rounded transition-colors"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      ))}
    </div>
  );
};

export default EditorTabs;