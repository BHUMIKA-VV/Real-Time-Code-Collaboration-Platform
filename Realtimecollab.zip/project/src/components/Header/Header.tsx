import React from 'react';
import { Code2, Users, Settings, Play, Save, Share, LogOut, Copy, Check } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useCollaboration } from '../../context/CollaborationContext';
import { useAuth } from '../../context/AuthContext';

const Header: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { connectedUsers } = useCollaboration();
  const { user, logout, roomInfo } = useAuth();
  const [copied, setCopied] = React.useState(false);

  const copyRoomId = async () => {
    if (roomInfo?.id) {
      try {
        await navigator.clipboard.writeText(roomInfo.id);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (error) {
        console.error('Failed to copy room ID:', error);
      }
    }
  };

  return (
    <div className="h-12 bg-gray-800 border-b border-gray-700 flex items-center justify-between px-4">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <Code2 className="w-6 h-6 text-blue-400" />
          <span className="text-lg font-semibold">CodeCollab</span>
        </div>
        <div className="flex items-center space-x-3">
          <div className="text-sm text-gray-400">
            {roomInfo?.name || 'Room'}
          </div>
          {roomInfo?.id && (
            <button
              onClick={copyRoomId}
              className="flex items-center space-x-1 px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-xs transition-colors"
              title="Copy Room ID"
            >
              {copied ? (
                <>
                  <Check className="w-3 h-3 text-green-400" />
                  <span className="text-green-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span className="text-gray-300">Room ID</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      <div className="flex items-center space-x-3">
        <button className="flex items-center space-x-2 px-3 py-1.5 bg-green-600 hover:bg-green-700 rounded-md text-sm transition-colors">
          <Play className="w-4 h-4" />
          <span>Run</span>
        </button>
        
        <button className="flex items-center space-x-2 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 rounded-md text-sm transition-colors">
          <Save className="w-4 h-4" />
          <span>Save</span>
        </button>

        <button className="flex items-center space-x-2 px-3 py-1.5 bg-purple-600 hover:bg-purple-700 rounded-md text-sm transition-colors">
          <Share className="w-4 h-4" />
          <span>Share</span>
        </button>

        <div className="flex items-center space-x-2 text-sm text-gray-300">
          <Users className="w-4 h-4" />
          <span>{connectedUsers.length} online</span>
        </div>

        <div className="flex items-center space-x-2 text-sm text-gray-300">
          <div className="w-2 h-2 bg-green-400 rounded-full"></div>
          <span>{user?.username}</span>
        </div>

        <button
          onClick={toggleTheme}
          className="p-2 hover:bg-gray-700 rounded-md transition-colors"
        >
          <Settings className="w-4 h-4" />
        </button>

        <button
          onClick={logout}
          className="flex items-center space-x-1 px-3 py-1.5 bg-red-600 hover:bg-red-700 rounded-md text-sm transition-colors"
          title="Logout"
        >
          <LogOut className="w-4 h-4" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};

export default Header;