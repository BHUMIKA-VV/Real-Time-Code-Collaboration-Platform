import React, { useState } from 'react';
import { 
  Folder, 
  FolderOpen, 
  File, 
  FileText, 
  Code, 
  Coffee,
  Hash,
  Database,
  ChevronRight,
  ChevronDown
} from 'lucide-react';
import { useFile } from '../../context/FileContext';

interface FileItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  extension?: string;
  children?: FileItem[];
  isOpen?: boolean;
}

const mockFiles: FileItem[] = [
  {
    id: '1',
    name: 'src',
    type: 'folder',
    isOpen: true,
    children: [
      { id: '2', name: 'components', type: 'folder', isOpen: true, children: [
        { id: '3', name: 'Editor.tsx', type: 'file', extension: 'tsx' },
        { id: '4', name: 'Sidebar.tsx', type: 'file', extension: 'tsx' },
      ]},
      { id: '5', name: 'utils', type: 'folder', children: [
        { id: '6', name: 'helpers.js', type: 'file', extension: 'js' },
        { id: '7', name: 'api.js', type: 'file', extension: 'js' },
      ]},
      { id: '8', name: 'App.tsx', type: 'file', extension: 'tsx' },
      { id: '9', name: 'index.css', type: 'file', extension: 'css' },
    ]
  },
  { id: '10', name: 'public', type: 'folder', children: [
    { id: '11', name: 'index.html', type: 'file', extension: 'html' },
  ]},
  { id: '12', name: 'package.json', type: 'file', extension: 'json' },
  { id: '13', name: 'README.md', type: 'file', extension: 'md' },
];

const Sidebar: React.FC = () => {
  const [files, setFiles] = useState<FileItem[]>(mockFiles);
  const { activeFile, setActiveFile } = useFile();

  const getFileIcon = (extension?: string) => {
    switch (extension) {
      case 'tsx':
      case 'ts':
        return <Code className="w-4 h-4 text-blue-400" />;
      case 'js':
      case 'jsx':
        return <Code className="w-4 h-4 text-yellow-400" />;
      case 'css':
      case 'scss':
        return <Hash className="w-4 h-4 text-pink-400" />;
      case 'html':
        return <FileText className="w-4 h-4 text-orange-400" />;
      case 'json':
        return <Database className="w-4 h-4 text-green-400" />;
      case 'md':
        return <FileText className="w-4 h-4 text-gray-400" />;
      case 'java':
        return <Coffee className="w-4 h-4 text-red-400" />;
      default:
        return <File className="w-4 h-4 text-gray-400" />;
    }
  };

  const toggleFolder = (folderId: string) => {
    const toggleInFiles = (items: FileItem[]): FileItem[] => {
      return items.map(item => {
        if (item.id === folderId && item.type === 'folder') {
          return { ...item, isOpen: !item.isOpen };
        }
        if (item.children) {
          return { ...item, children: toggleInFiles(item.children) };
        }
        return item;
      });
    };
    setFiles(toggleInFiles(files));
  };

  const renderFiles = (items: FileItem[], depth = 0) => {
    return items.map(item => (
      <div key={item.id} className="select-none">
        <div
          className={`flex items-center space-x-2 px-2 py-1 text-sm cursor-pointer hover:bg-gray-700 rounded-md ${
            activeFile?.id === item.id ? 'bg-gray-700 text-blue-400' : 'text-gray-300'
          }`}
          style={{ paddingLeft: `${8 + depth * 16}px` }}
          onClick={() => {
            if (item.type === 'folder') {
              toggleFolder(item.id);
            } else {
              setActiveFile(item);
            }
          }}
        >
          {item.type === 'folder' ? (
            <>
              {item.isOpen ? (
                <ChevronDown className="w-3 h-3" />
              ) : (
                <ChevronRight className="w-3 h-3" />
              )}
              {item.isOpen ? (
                <FolderOpen className="w-4 h-4 text-blue-400" />
              ) : (
                <Folder className="w-4 h-4 text-blue-400" />
              )}
            </>
          ) : (
            <>
              <div className="w-3" />
              {getFileIcon(item.extension)}
            </>
          )}
          <span className="truncate">{item.name}</span>
        </div>
        {item.type === 'folder' && item.isOpen && item.children && (
          <div>{renderFiles(item.children, depth + 1)}</div>
        )}
      </div>
    ));
  };

  return (
    <div className="w-64 bg-gray-800 border-r border-gray-700 flex flex-col">
      <div className="p-3 border-b border-gray-700">
        <h2 className="text-sm font-medium text-gray-300 uppercase tracking-wide">
          Explorer
        </h2>
      </div>
      <div className="flex-1 overflow-y-auto p-2">
        {renderFiles(files)}
      </div>
    </div>
  );
};

export default Sidebar;