import React from 'react';
import { User } from 'lucide-react';
import { useCollaboration } from '../../context/CollaborationContext';

const UserPresence: React.FC = () => {
  const { connectedUsers } = useCollaboration();

  return (
    <div className="h-8 bg-gray-800 border-b border-gray-700 flex items-center justify-between px-4">
      <div className="flex items-center space-x-2">
        <span className="text-xs text-gray-400">Connected users:</span>
        <div className="flex -space-x-2">
          {connectedUsers.map((user) => (
            <div
              key={user.id}
              className="relative group"
            >
              <div 
                className="w-6 h-6 rounded-full border-2 border-gray-700 flex items-center justify-center text-xs font-medium"
                style={{ backgroundColor: user.color }}
              >
                {user.name.charAt(0).toUpperCase()}
              </div>
              <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
                {user.name}
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="flex items-center space-x-2 text-xs text-gray-400">
        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
        <span>Real-time sync active</span>
      </div>
    </div>
  );
};

export default UserPresence;