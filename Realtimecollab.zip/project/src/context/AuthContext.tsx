import React, { createContext, useContext, useState, ReactNode } from 'react';

interface User {
  id: string;
  username: string;
  color: string;
  roomId: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (userData: { username: string; roomId: string; isNewRoom: boolean }) => void;
  logout: () => void;
  roomInfo: {
    id: string;
    name: string;
    createdAt: Date;
    isOwner: boolean;
  } | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

const generateUserColor = () => {
  const colors = [
    '#3B82F6', // blue
    '#10B981', // green
    '#8B5CF6', // purple
    '#F59E0B', // yellow
    '#EF4444', // red
    '#06B6D4', // cyan
    '#84CC16', // lime
    '#F97316', // orange
    '#EC4899', // pink
    '#6366F1', // indigo
  ];
  return colors[Math.floor(Math.random() * colors.length)];
};

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [roomInfo, setRoomInfo] = useState<{
    id: string;
    name: string;
    createdAt: Date;
    isOwner: boolean;
  } | null>(null);

  const login = (userData: { username: string; roomId: string; isNewRoom: boolean }) => {
    const newUser: User = {
      id: `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      username: userData.username,
      color: generateUserColor(),
      roomId: userData.roomId,
    };

    setUser(newUser);
    setRoomInfo({
      id: userData.roomId,
      name: userData.isNewRoom ? `${userData.username}'s Room` : 'Joined Room',
      createdAt: new Date(),
      isOwner: userData.isNewRoom,
    });

    // Store in localStorage for persistence
    localStorage.setItem('codecollab_user', JSON.stringify(newUser));
    localStorage.setItem('codecollab_room', JSON.stringify({
      id: userData.roomId,
      name: userData.isNewRoom ? `${userData.username}'s Room` : 'Joined Room',
      createdAt: new Date().toISOString(),
      isOwner: userData.isNewRoom,
    }));
  };

  const logout = () => {
    setUser(null);
    setRoomInfo(null);
    localStorage.removeItem('codecollab_user');
    localStorage.removeItem('codecollab_room');
  };

  // Check for existing session on mount
  React.useEffect(() => {
    const savedUser = localStorage.getItem('codecollab_user');
    const savedRoom = localStorage.getItem('codecollab_room');
    
    if (savedUser && savedRoom) {
      try {
        const userData = JSON.parse(savedUser);
        const roomData = JSON.parse(savedRoom);
        setUser(userData);
        setRoomInfo({
          ...roomData,
          createdAt: new Date(roomData.createdAt),
        });
      } catch (error) {
        console.error('Error parsing saved session:', error);
        logout();
      }
    }
  }, []);

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      login,
      logout,
      roomInfo,
    }}>
      {children}
    </AuthContext.Provider>
  );
};