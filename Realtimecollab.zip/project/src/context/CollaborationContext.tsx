import React, { createContext, useContext, useState, ReactNode } from 'react';
import { useAuth } from './AuthContext';

interface User {
  id: string;
  name: string;
  color: string;
  cursor?: {
    line: number;
    column: number;
  };
}

interface CollaborationContextType {
  connectedUsers: User[];
  currentUser: User | null;
  setCurrentUser: (user: User) => void;
}

const CollaborationContext = createContext<CollaborationContextType | undefined>(undefined);

export const useCollaboration = () => {
  const context = useContext(CollaborationContext);
  if (!context) {
    throw new Error('useCollaboration must be used within a CollaborationProvider');
  }
  return context;
};

interface CollaborationProviderProps {
  children: ReactNode;
}

export const CollaborationProvider: React.FC<CollaborationProviderProps> = ({ children }) => {
  const { user } = useAuth();
  const [connectedUsers, setConnectedUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Update connected users when auth user changes
  React.useEffect(() => {
    if (user) {
      // Only show the current user initially
      const users: User[] = [
        {
          id: user.id,
          name: user.username,
          color: user.color
        }
      ];
      setConnectedUsers(users);
      setCurrentUser(users[0]);
    } else {
      setConnectedUsers([]);
      setCurrentUser(null);
    }
  }, [user]);

  return (
    <CollaborationContext.Provider value={{
      connectedUsers,
      currentUser,
      setCurrentUser,
    }}>
      {children}
    </CollaborationContext.Provider>
  );
};