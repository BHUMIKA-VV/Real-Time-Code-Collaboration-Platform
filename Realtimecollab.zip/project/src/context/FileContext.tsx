import React, { createContext, useContext, useState, ReactNode } from 'react';

interface FileItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  extension?: string;
  content?: string;
}

interface FileContextType {
  activeFile: FileItem | null;
  setActiveFile: (file: FileItem) => void;
  openFiles: FileItem[];
  closeFile: (fileId: string) => void;
  createFile: (name: string, type: 'file' | 'folder') => void;
}

const FileContext = createContext<FileContextType | undefined>(undefined);

export const useFile = () => {
  const context = useContext(FileContext);
  if (!context) {
    throw new Error('useFile must be used within a FileProvider');
  }
  return context;
};

interface FileProviderProps {
  children: ReactNode;
}

export const FileProvider: React.FC<FileProviderProps> = ({ children }) => {
  const [activeFile, setActiveFileState] = useState<FileItem | null>(null);
  const [openFiles, setOpenFiles] = useState<FileItem[]>([]);

  const setActiveFile = (file: FileItem) => {
    setActiveFileState(file);
    if (!openFiles.find(f => f.id === file.id)) {
      setOpenFiles(prev => [...prev, file]);
    }
  };

  const closeFile = (fileId: string) => {
    setOpenFiles(prev => prev.filter(f => f.id !== fileId));
    if (activeFile?.id === fileId) {
      const remainingFiles = openFiles.filter(f => f.id !== fileId);
      setActiveFileState(remainingFiles.length > 0 ? remainingFiles[remainingFiles.length - 1] : null);
    }
  };

  const createFile = (name: string, type: 'file' | 'folder') => {
    // Implementation for creating new files
    console.log('Creating file:', name, type);
  };

  return (
    <FileContext.Provider value={{
      activeFile,
      setActiveFile,
      openFiles,
      closeFile,
      createFile,
    }}>
      {children}
    </FileContext.Provider>
  );
};